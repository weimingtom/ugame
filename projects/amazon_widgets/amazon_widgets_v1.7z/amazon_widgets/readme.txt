1. url:
	http://studio-mebius.product.co.jp/
	http://g-ecx.images-amazon.com/images/G/09/associates/widgets//20070822/JP/Flash/Widgets._V143365525_.swf?ServiceVersion=20070822&MarketPlace=JP&ID=V20070822/JP/studio08-22/8010/8a71af22-c8b6-4e1c-8e9f-fb4929b74ff9

2. compile order:
	loading->carousel->widgets

3. change:
	Review.Review:
		"star" + getStringRating() + "_tpng.png"
		
	carousel.loadData:
		Utils.getFromServer("q_v5.txt", params, resultHandler, faultHandler);
		
	Widgets.postLoadProperties
		Utils.getFromServer("q_v2.txt", params, resultHandler, faultHandler);
	
	Metrics.recordImpression
	Metrics.logAction
		comment
	
	Widgets.completed
	Widgets.postLoadProperties
		comment Security.loadPolicyFile
	
	PopoverProduct.hasPlayRecorded
		public var hasPlayRecorded:Boolean = true //false



	